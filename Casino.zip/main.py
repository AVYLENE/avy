import random

class Casino:
    def __init__(self):
        self.balance = 1000
        self.games_played = {'blackjack': 0, 'tragaperras': 0, 'ruleta': 0, 'dados': 0}
        self.wins = 0
        self.losses = 0
        self.history = []

    def display_menu(self):
        print("\n--- Menú del Casino ---")
        print("1. Blackjack")
        print("2. Tragaperras")
        print("3. Ruleta Americana")
        print("4. Dados (Craps)")
        print("5. Ver Presupuesto")
        print("6. Salir")

    def get_bet(self):
        while True:
            try:
                bet = int(input("Ingrese su apuesta ($100 - $500): "))
                if 100 <= bet <= 500:
                    return bet
                else:
                    print("La apuesta debe estar entre $100 y $500.")
            except ValueError:
                print("Por favor, ingrese un número válido.")

    def blackjack(self):
        self.games_played['blackjack'] += 1
        bet = self.get_bet()
        player_hand = [random.randint(1, 11), random.randint(1, 11)]
        dealer_hand = [random.randint(1, 11), random.randint(1, 11)]

        print(f"Su mano: {player_hand}, Mano del crupier: {dealer_hand[0]}")
        while True:                
            choice = input("¿Quieres pedir otra carta? (s/n): ")
            if choice.lower() == 's':
                player_hand.append(random.randint(1, 11))
                print(f"Tu mano: {player_hand}")
                if sum(player_hand) > 21:
                    print("Te has pasado de 21. ¡Has perdido!")
                    self.losses += 1
                    self.balance -= bet
                    self.history.append(f"Juego de Blackjack: Perdiste ${bet}")
                    return
            else:
                break
                
        

        player_total = sum(player_hand)
        dealer_total = sum(dealer_hand)
        print(f"Tu mano: {player_hand}, Total: {player_total}")
        

        if player_total > 21:
            print("Te pasaste de 21. ¡Perdiste!")
            self.balance -= bet
            self.losses += 1
        elif player_total == 21:
            print("¡Blackjack! Ganaste.")
            self.balance += bet * 1.5
            self.wins += 1
        else:
            action = input("¿Quieres 'plantarte' o 'pedir' otra carta? ").lower()
            if action == 'pedir':
                player_hand.append(random.randint(1, 11))
                player_total = sum(player_hand)
                print(f"Tu nueva mano: {player_hand}")
                if player_total > 21:
                    print("Te pasaste de 21. ¡Perdiste!")
                    self.balance -= bet
                    self.losses += 1
                elif player_total > dealer_total:
                    print("Ganaste.")
                    self.balance += bet
                    self.wins += 1
                else:
                    print("Perdiste.")
                    self.balance -= bet
                    self.losses += 1
            else:
                if player_total > dealer_total:
                    print("Ganaste.")
                    self.balance += bet
                    self.wins += 1
                else:
                    print("Perdiste.")
                    self.balance -= bet
                    self.losses += 1

        self.history.append(('blackjack', bet, self.balance))

    def tragaperras(self):
        self.games_played['tragaperras'] += 1
        bet = self.get_bet()
        symbols = ["🍒", "🍋", "🍊", "🍉", "🍇"]
        reels = [random.choices(symbols, k=5) for _ in range(3)]

        print("Resultados de la tragaperras:")
        for reel in reels:
            print(" | ".join(reel))

        # Simulación simple de ganancias
        if reels[0][0] == reels[1][0] == reels[2][0]:
            print("¡Ganaste!")
            self.balance += bet * 10
            self.wins += 1
        else:
            print("Perdiste.")
            self.balance -= bet
            self.losses += 1

        self.history.append(('tragaperras', bet, self.balance))

    def ruleta(self):
        self.games_played['ruleta'] += 1
        bet = self.get_bet()
        print("Opciones de apuestas: Rojo, Negro, Par, Impar")
        color = input("¿En qué color deseas apostar? ").lower()

        result = random.choice(['rojo', 'negro', 'par', 'impar'])
        print(f"Resultado: {result}")

        if color == result:
            print("¡Ganaste!")
            self.balance += bet * 2
            self.wins += 1
        else:
            print(" Perdiste.")
            self.balance -= bet
            self.losses += 1

        self.history.append(('ruleta', bet, self.balance))

    def dados(self):
        self.games_played['dados'] += 1
        bet = self.get_bet()
        print("Apuestas disponibles: Línea de pase, No pase")
        bet_type = input("¿Qué tipo de apuesta deseas hacer? ").lower()

        roll = random.randint(1, 6) + random.randint(1, 6)
        print(f"Resultado de los dados: {roll}")

        if (bet_type == 'línea de pase' and roll in [7, 11]) or (bet_type == 'no pase' and roll in [2, 3]):
            print("¡Ganaste!")
            self.balance += bet
            self.wins += 1
        else:
            print("Perdiste.")
            self.balance -= bet
            self.losses += 1

        self.history.append(('dados', bet, self.balance))

    def view_balance(self):
        print(f"Saldo actual: ${self.balance}")

    def exit_casino(self):
        print("\n--- Resumen de Actividad ---")
        print(f"Saldo final: ${self.balance}")
        print(f"Número de juegos jugados: {sum(self.games_played.values())}")
        for game, count in self.games_played.items():
            print(f"{game.capitalize()}: {count} veces")
        print(f"Número total de victorias: {self.wins}")
        print(f"Número total de derrotas: {self.losses}")
        if self.history:
            most_lost_game = max(self.history, key=lambda x: x[1] if x[2] < self.balance else 0)
            print(f"Juego en el que más perdiste: {most_lost_game[0]} con una apuesta de ${most_lost_game[1]}")
        print("Gracias por jugar. ¡Hasta la próxima!")

    def run(self):
        while True:
            self.display_menu()
            choice = input("Seleccione una opción: ")
            if choice == '1':
                self.blackjack()
            elif choice == '2':
                self.tragaperras()
            elif choice == '3':
                self.ruleta()
            elif choice == '4':
                self.dados()
            elif choice == '5':
                self.view_balance()
            elif choice == '6':
                self.exit_casino()
                break
            else:
                print("Opción no válida. Intente de nuevo.")

if __name__ == "__main__":
    casino = Casino()
    casino.run()
    def blackjack_advice(self, player_hand, dealer_upcard):
        """
        Proporciona consejos al jugador basados en estrategias de conteo de cartas.
        """
        player_total = sum(player_hand)
        dealer_upcard_value = dealer_upcard[0]

        # Reglas básicas del blackjack
        if player_total <= 11:
            return "Pedir"
        elif player_total == 12:
            if dealer_upcard_value in range(4, 7):
                return "Pedir"
            else:
                return "Plantarse"
        elif player_total in range(13, 17):
            if dealer_upcard_value in range(2, 7):
                return "Plantarse"
            else:
                return "Pedir"
        elif player_total >= 17:
            return "Plantarse"

        # Estrategias de conteo de cartas (simplificadas)
        # (Estas estrategias requieren un conteo de cartas más sofisticado para ser realmente efectivas)
        # ... (Agregar lógica de conteo de cartas aquí)
        # ...

        return "Plantarse"  # Por defecto, plantarse si no se cumple ninguna otra regla